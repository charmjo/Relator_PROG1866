<nav class="top_menu">
    <ul>
      <li>
        <a href="index.php">Order Form</a>
      </li>
      <li>
        <a href="orders.php">All Orders</a>
      </li>
      <li>
        <a href="login.php">Login</a>
      </li>
      <li>
        <a href="logout.php">Logout</a>
      </li>
    </ul>
</nav>