<footer>
    <p> &copy;2023 - Charm Johannes Relator. All rights reserved. </p>
</footer>