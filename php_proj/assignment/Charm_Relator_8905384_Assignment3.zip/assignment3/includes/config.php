<?php
    include('constants.php');
    include('globalvars.php');
?>