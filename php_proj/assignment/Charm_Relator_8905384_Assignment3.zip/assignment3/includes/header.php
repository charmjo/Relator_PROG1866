<header>
    <img src="assets/images/HatchfulExport-All/logo.png" alt="logo">
</header>