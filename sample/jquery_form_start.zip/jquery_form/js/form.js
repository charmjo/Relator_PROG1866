/*
    Using jQuery for form validations
*/

